package com.neig9644.workstationhelper;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;

public class MainActivity extends Activity {
    LinearLayout root;
    TextView status;
    Switch autoSwitch;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        root = new LinearLayout(this); root.setOrientation(1); root.setPadding(28,28,28,28); root.setBackgroundColor(Color.rgb(18,22,39));
        ScrollView scroll = new ScrollView(this); scroll.addView(root); setContentView(scroll);
        TextView title = text("别坐我工位助手", 27, Color.WHITE); root.addView(title);
        TextView sub = text("独立安卓辅助工具 · 原型 0.1.0", 14, 0xFFB9C0D8); root.addView(sub);
        status = text("状态：尚未授权无障碍服务", 15, 0xFFFFD27A); status.setPadding(0,24,0,18); root.addView(status);
        addButton("开启无障碍授权", v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        addButton("开启悬浮窗权限", v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)));
        autoSwitch = new Switch(this); autoSwitch.setText("全自动操作（测试阶段默认关闭）"); autoSwitch.setTextColor(Color.WHITE); autoSwitch.setPadding(0,24,0,24); root.addView(autoSwitch);
        autoSwitch.setOnCheckedChangeListener((v, checked) -> {
            if (checked) { autoSwitch.setChecked(false); Toast.makeText(this,"自动操作尚未完成屏幕识别校准，暂不可启动。",Toast.LENGTH_LONG).show(); }
        });
        section("自动操作"); addFeature("一键放置物品", "待完成：识别商店卡片、价格和放置位置"); addFeature("自动升级工位", "待完成：识别工位升级按钮与金币成本"); addFeature("自动升级门", "待完成：识别门的等级、耐久和升级成本"); addFeature("自动维修", "待完成：识别设施血量并判断维修时机");
        section("金币与资源策略"); addFeature("收益效率分析", "待完成：统计每分钟金币收益并比较投资回报"); addFeature("资源保留线", "规划中：金币/水滴不足时停止购买"); addFeature("购买优先级", "规划中：按收益、成本和防守需求排序");
        section("技能冷却管理"); addFeature("冷却监控与就绪提醒", "待完成：识别技能图标、倒计时和可用状态"); addFeature("自动释放/合法刷新", "仅使用游戏内允许的技能和刷新道具");
        section("安全控制"); addFeature("暂停与紧急停止", "自动化启动后必须始终可手动停止"); addFeature("异常保护", "识别失败、弹窗或资源不足时暂停，避免误触");
        TextView note = text("重要：当前版本是功能框架，不会伪称已实现自动识别。实际游戏可能使用 Unity 等画布渲染，需进一步验证屏幕识别和点击坐标。",13,0xFFB9C0D8); note.setPadding(0,24,0,10); root.addView(note);
    }
    TextView text(String s,int size,int color){ TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t; }
    void section(String s){ TextView t=text(s,19,0xFF8FADFF);t.setPadding(0,26,0,8);root.addView(t); }
    void addFeature(String name,String desc){ LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(18,14,18,14);box.setBackgroundColor(0xFF272D46);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,6,0,6);root.addView(box,p);box.addView(text(name,16,Color.WHITE));TextView d=text(desc,12,0xFFB9C0D8);d.setPadding(0,5,0,0);box.addView(d); }
    void addButton(String s,View.OnClickListener l){ Button b=new Button(this);b.setText(s);b.setOnClickListener(l);root.addView(b,new LinearLayout.LayoutParams(-1,-2)); }
}
