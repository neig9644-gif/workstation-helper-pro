package com.neig9644.workstationhelper;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.os.Build;
import android.graphics.Path;
import android.accessibilityservice.GestureDescription;

/** User-authorized accessibility bridge. Automation remains disabled until game-specific UI is validated. */
public class GameAccessibilityService extends AccessibilityService {
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* Future: inspect visible UI text/nodes. */ }
    @Override public void onInterrupt() { }
    public boolean clickNodeByText(String label) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        try {
            for (AccessibilityNodeInfo node : root.findAccessibilityNodeInfosByText(label)) {
                if (node != null && node.isClickable()) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }
        } finally { root.recycle(); }
        return false;
    }
    public void tap(float x,float y) {
        if (Build.VERSION.SDK_INT < 24) return;
        Path path = new Path(); path.moveTo(x,y);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,80)).build();
        dispatchGesture(gesture,null,null);
    }
}
